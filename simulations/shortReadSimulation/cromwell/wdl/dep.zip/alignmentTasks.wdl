version 1.0

import "Structs.wdl"

task combineFASTQ{
    input {
        Array[File] Fastqs
        String Output
    }

    RuntimeAttr default_attr = object {
      cpu_cores: 1,
      mem_gb: 1.7,
      disk_gb: ceil(10.0 + input_size),
      boot_disk_gb: 10,
      preemptible_tries: 3,
      max_retries: 1
    }

    runtime {
      cpu: default_attr.cpu_cores
      memory: mem_gb + " GiB"
      disks: "local-disk " + default_attr.disk_gb + " HDD"
      bootDiskSizeGb: default_attr.boot_disk_gb
      preemptible: default_attr.preemptible_tries
      maxRetries: default_attr.max_retries
    }

    command <<<
        > Output
        for element in ~{Fastqs};
        do
            cat $element >> Output
    >>>

    output {
        File combinedFile = Output
    }
}