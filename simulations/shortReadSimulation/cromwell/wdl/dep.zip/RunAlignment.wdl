version 1.0

import "CombineFiles.wdl" as comb
import "RemovePolyGArtifacts.wdl" as polyg
import "BwaAlignment.wdl" as bwa

workflow RunAlignment {
  meta {
    allowNestedInputs: true
  }

  input {
        Array[File] HG002_Foward
        Array[File] HG002_Reverse
        Array[File] HG00438_Foward
        Array[File] HG00438_Reverse
        Array[File] HG02257_Foward
        Array[File] HG02257_Reverse
        Array[File] HG02486_Foward
        Array[File] HG02486_Reverse
        Array[File] HG02622_Foward
        Array[File] HG02622_Reverse

        File Reference
        File RefFAI
        File RefAMB
        File RefANN
        File RefBWT
        File RefPAC
        File RefSA
        File? RefALT

        Int read_length

        String FastpDocker
        String BwaDocker
    
  }

  call comb.CombineFiles as CombineFiles {
    input:
        HG002_Foward=HG002_Foward,
        HG002_Reverse=HG002_Reverse,
        HG00438_Foward=HG00438_Foward,
        HG00438_Reverse=HG00438_Reverse,
        HG02257_Foward=HG02257_Foward,
        HG02257_Reverse=HG02257_Reverse,
        HG02486_Foward=HG02486_Foward,
        HG02486_Reverse=HG02486_Reverse,
        HG02622_Foward=HG02622_Foward,
        HG02622_Reverse=HG02622_Reverse
  }

  Array[Array[File]] samples = [CombineFiles.HG002, CombineFiles.HG00438, CombineFiles.HG02257, CombineFiles.HG02486, CombineFiles.HG02622]

  scatter (sample in samples) {

    call polyg.RemovePolyG as PolyG {
      input:
        Fastq=sample,
        read_length=read_length,
        FastpDocker=FastpDocker
    }
    
    call bwa.BwaAlignment as BWA {
      input:
        Fastq=Fastq,
        Reference=Reference,
        RefFAI=RefFAI,
        RefAMB=RefAMB,
        RefANN=RefANN,
        RefBWT=RefBWT,
        RefPAC=RefPAC,
        RefSA=RefSA,
        RefALT=RefALT,
        BwaDocker=BwaDocker
    }
  }
}
